Welcome to camera functions built by Avi Tannenbaum 7/28/2016/
This is a camera fucntions folder used for integration camera through javascript to use the camera on a phone take a picture and proccess it or maybe even upload it to google drive and perfor m more fucntions from there.

Please use this plugin writin by Avi Tannenbaum with the concent of Avi Tannebaum.
Copyrite.\

You may use this plugin freely but all I ask is that you put my name in the credits to give me credit for writing this function.

Terms subject to change. 

Using this function means you agree to the terms.

enjoyt the use of this REST Google tm api.

Ofcours eall google, google drive and and google related products belong to google and are not affiliated with Avi Tannenbaum or StarShows Studios inc. 
