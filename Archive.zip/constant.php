<?php
// Database constants
define('DB_SERVER', "localhost");
define('DB_USER', "starshow_aibwp");
define('DB_PASSWORD', "Superflower86@");
define('DB_DATABASE', "starshow_aibwp");
define('DB_DRIVER', "mysql");
?>