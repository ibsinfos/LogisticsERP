<?php
$xfer = $_POST['xfer'];
header("location: $xfer");
exit;
?>