<!--

<!DOCTYPE HTML PUBLIC "\\W#C\\DTD HTML 4.01\\EN" "\erp\aibwp\Finance\Pages\frameworks\HTML\strict.dtd">

<html>

<head>
<title>View Framwework for the collections manager<\title>
<\head>
<body>




<\body>
<\html>
-->

<?php

include '\erp\aibwp\Finance\Pages\Collections\collectionDatabaseManagerView.php';



?>