
<div class="Mail-Form-Div">
<h1>Send a collection notice to customer.</h1>
<form method="GET" name="email_form" id="email_form" action="/erp/aibwp/Mail/Functions/emailSender.php">
<p style="color:#EA0075;">Enter the customers email</p>
<!--Imput the email form to the cusrtomer -->
 <label for="title">Email:</label>
 <input type="text" name="email2" id="email2" value=""> 
 <input name="emailSubmit" id="submit" type="submit" value="Send" name="Send">
 </form>

 
 </div>