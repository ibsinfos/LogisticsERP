This code was written and produced by Avi Tannenbaum 2016.
All rites reseved by Avi Tannenbaum.

All I Ask is,
If you plan on using this code please remeber to give credit to the developer. Me.
Really apreachiate it.
Avi T.

