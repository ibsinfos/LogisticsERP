<?php

// This is the update record document.
// Designed and writen by Avi Tannenbaum All rites reserved StarShows Studios ERP Systems 2016. 
$markerfortext = "=======";
echo "<br>" . $markerfortext . " <br> <br> Update records page document loaded successfully. Thank you for including me. <br> <br>" . $markerfortext ." <b>";

?>