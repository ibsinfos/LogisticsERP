function resetform() {
document.getElementById("form-ajax").reset();
}