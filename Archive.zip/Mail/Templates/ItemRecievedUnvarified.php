<?php
echo "<h1> Unvarified email template loaded successfully. </h1>";
?>