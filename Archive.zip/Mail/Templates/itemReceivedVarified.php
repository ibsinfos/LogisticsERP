<?php 
echo "<br> <h1> The varified email template has loaded successfully. </h1> <br>";
echo "<p> the varified return email notification email will be placed here </p>"
// this hsould be the email template loaded when we want to report to a customer thart an item has arrived and will be varified shortly, 


?>