<?php
echo "This is a test php script";
?>

<?php
$test = 16 /* +15 */ + 5;
$message = " Welcome to Milton ERP";
echo $test, $message;
/*This is a test comment */

ECHO "Welcome world<br>";
?>
